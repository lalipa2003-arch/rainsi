# Rainsi

Rainsi is a browser-side Lua runtime built with WebAssembly. It provides one TypeScript API for running Lua 5.1, 5.2, 5.3, 5.4, and 5.5 in the browser.

The runtime includes the WASI compatibility layer and JavaScript/WASM glue needed by the bundled Lua builds. There is no React UI or demo application in this repository; Rainsi is intended to be used as a runtime/library.

## Supported Lua versions

- Lua 5.1.5
- Lua 5.2.4
- Lua 5.3.6
- Lua 5.4.7
- Lua 5.5.1

## Installation

```bash
npm install rainsi-lua
```

## Quick start

```ts
import { LuaEngine } from 'rainsi-lua';

const lua = await LuaEngine.create({ version: '5.4.7' });

const result = await lua.run(`
  local x = 20
  return x + 22
`);

console.log(result);

lua.close();
```

## API

### `LuaEngine.create(options)`

Creates and initializes a Lua runtime.

```ts
const lua = await LuaEngine.create({
  version: '5.4.7'
});
```

Available versions are `5.1.5`, `5.2.4`, `5.3.6`, `5.4.7`, and `5.5.1`.

### `lua.run(code)`

Executes Lua source code and returns the execution result.

```ts
const result = await lua.run('return 6 * 7');
console.log(result);
```

### `lua.call(name, ...args)`

Calls a Lua function through the runtime API.

```ts
await lua.run(`
  function add(a, b)
    return a + b
  end
`);

const result = await lua.call('add', 10, 32);
```

### `lua.set(name, value)` / `lua.get(name)`

Set and retrieve values exposed through the Lua global environment.

```ts
await lua.set('answer', 42);
const answer = await lua.get('answer');
```

### `lua.register(name, fn)`

Register a JavaScript function for Lua code to call.

```ts
await lua.register('hostAdd', (a, b) => a + b);

await lua.run(`
  local result = hostAdd(2, 3)
  print(result)
`);
```

### `lua.close()`

Releases the runtime resources when the engine is no longer needed.

## Architecture

Rainsi is made up of a small TypeScript runtime layer around prebuilt Lua WebAssembly modules:

```text
TypeScript API
     |
     +-- LuaEngine
     |
     +-- WASI compatibility layer
     |
     +-- JS/WASM trampoline + patching
     |
     +-- Lua 5.1–5.5 WebAssembly modules
```

The important runtime pieces are kept in `src/`:

- `lua-engine.ts` — main runtime and Lua API
- `wasi-polyfill.ts` — browser-side WASI compatibility functions
- `trampoline.ts` — JavaScript/WASM callback bridge
- `wasm-patcher.ts` — WebAssembly binary patching support
- `types.ts` — public TypeScript types
- `index.ts` — package exports

The corresponding Lua WebAssembly binaries are stored in `wasm/`.

## Building from source

```bash
npm install
npm run build
```

The compiled TypeScript output is written to `dist/`.

## Browser use

Rainsi is designed for browser environments. The bundled WASM modules are package assets, so applications using Rainsi should make sure their bundler can serve `.wasm` files from the package's `wasm/` directory.

## Status

Rainsi is an experimental project. The API and implementation may change between releases.

If you find a runtime bug, compatibility issue, or problem with a particular Lua version, please open an issue with a minimal reproduction.

## License

MIT

See `LICENSE` for the full license text.

## Repository

https://github.com/lalipa2003-arch/rainsi
