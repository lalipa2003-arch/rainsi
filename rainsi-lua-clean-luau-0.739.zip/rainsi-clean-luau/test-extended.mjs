import { LuaEngine } from './dist/index.js';

async function runExtendedTests() {
  console.log('====================================================');
  console.log('🔬 DEEP ADVANCED LUAU 0.739 & WASI TESTS');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (!condition) {
      console.error(`❌ FAIL: ${message}`);
      failed++;
      throw new Error(`Assertion failed: ${message}`);
    } else {
      console.log(`✅ PASS: ${message}`);
      passed++;
    }
  }

  const engine = await LuaEngine.create({ version: '0.739' });

  // 1. Luau Coroutines
  console.log('--- 1. Coroutines ---');
  const coroRes = engine.doString(`
    local function producer()
      for i = 1, 3 do
        coroutine.yield(i * 10)
      end
      return 999
    end

    local co = coroutine.create(producer)
    local ok1, val1 = coroutine.resume(co)
    local ok2, val2 = coroutine.resume(co)
    local ok3, val3 = coroutine.resume(co)
    local ok4, val4 = coroutine.resume(co)

    return { val1 = val1, val2 = val2, val3 = val3, val4 = val4 }
  `);
  assert(coroRes.val1 === 10 && coroRes.val2 === 20 && coroRes.val3 === 30 && coroRes.val4 === 999, 'Luau coroutines work properly');

  // 2. Luau Buffer library
  console.log('\n--- 2. Buffer Library ---');
  const bufRes = engine.doString(`
    local b = buffer.create(16)
    buffer.writeu8(b, 0, 65)
    buffer.writeu8(b, 1, 66)
    buffer.writeu8(b, 2, 67)
    buffer.writestring(b, 3, "LuauBuffer")

    local c1 = buffer.readu8(b, 0)
    local c2 = buffer.readu8(b, 1)
    local c3 = buffer.readu8(b, 2)
    local s = buffer.readstring(b, 3, 10)

    return { c1 = c1, c2 = c2, c3 = c3, s = s }
  `);
  assert(bufRes.c1 === 65 && bufRes.c2 === 66 && bufRes.c3 === 67 && bufRes.s === 'LuauBuffer', 'Luau buffer library works properly');

  // 3. Lua Functions returned to JS and called multiple times
  console.log('\n--- 3. Lua Functions as JS Callables ---');
  engine.doString(`
    function makeAdder(start)
      local current = start
      return function(step)
        current += step
        return current
      end
    end
  `);
  const makeAdder = engine.get('makeAdder');
  assert(typeof makeAdder === 'function', 'makeAdder retrieved as JS function');
  const counter1 = makeAdder(100);
  assert(typeof counter1 === 'function', 'makeAdder returned closure');
  assert(counter1(5) === 105, 'Closure increment 1');
  assert(counter1(10) === 115, 'Closure increment 2');
  assert(counter1(-15) === 100, 'Closure decrement 3');

  // 4. WASI Virtual File System (VFS)
  console.log('\n--- 4. WASI Virtual File System ---');
  engine.writeFile('data/config.json', '{"engine": "luau", "version": "0.739"}');
  const vfsFiles = engine.listFiles();
  assert(vfsFiles.includes('data/config.json'), 'VFS file listed');

  const fileData = engine.readFile('data/config.json');
  const text = new TextDecoder().decode(fileData);
  assert(text.includes('"version": "0.739"'), 'VFS file read back directly');

  // 5. High-iteration CPU test & Garbage Collection
  console.log('\n--- 5. Intensive Heap & Garbage Collection ---');
  const gcRes = engine.doString(`
    for i = 1, 10000 do
      local t = { x = i, y = i * 2, name = "temp_" .. i }
    end
    gcinfo()
    return true
  `);
  assert(gcRes === true, 'Intensive heap allocations and GC cycles completed cleanly');

  engine.close();

  console.log('\n====================================================');
  console.log(`🎉 ALL ADVANCED TESTS PASSED! (${passed} passed, ${failed} failed)`);
  console.log('====================================================\n');
}

runExtendedTests().catch(err => {
  console.error('Fatal extended test error:', err);
  process.exit(1);
});
