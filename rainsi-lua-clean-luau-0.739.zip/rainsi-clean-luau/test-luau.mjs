import { LuaEngine } from './dist/index.js';

async function runTests() {
  console.log('====================================================');
  console.log('🧪 RUNNING COMPREHENSIVE LUAU 0.739 & WASI TEST SUITE');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (!condition) {
      console.error(`❌ FAIL: ${message}`);
      failed++;
      throw new Error(`Assertion failed: ${message}`);
    } else {
      console.log(`✅ PASS: ${message}`);
      passed++;
    }
  }

  // 1. Luau 0.739 Engine Instantiation
  console.log('--- Test 1: Luau 0.739 Engine Instantiation ---');
  let stdoutLogs = [];
  const engine = await LuaEngine.create({
    version: '0.739',
    onStdout: (t) => stdoutLogs.push(t),
  });
  assert(engine.version === '0.739', 'Engine initialized with version 0.739');

  // 2. Luau-specific Syntax: compound assignment, string interpolation, continue, types
  console.log('\n--- Test 2: Luau Syntax & Features ---');
  const luauSyntaxCode = `
    -- Type annotations
    type Vector2 = { x: number, y: number }

    local function addVec(a: Vector2, b: Vector2): Vector2
        return { x = a.x + b.x, y = a.y + b.y }
    end

    local v1: Vector2 = { x = 10, y = 20 }
    local v2: Vector2 = { x = 5, y = 15 }
    local res = addVec(v1, v2)

    -- Compound assignments
    local counter = 100
    counter += 50
    counter *= 2

    -- Continue statement & string interpolation
    local sum = 0
    for i = 1, 10 do
        if i % 2 == 0 then
            continue
        end
        sum += i
    end

    -- Luau string interpolation syntax \`...\`
    local interp = \`Result is {res.x + res.y}\`

    -- Return table
    return {
        vec = res,
        counter = counter,
        oddSum = sum,
        greeting = interp
    }
  `;
  const syntaxResult = engine.doString(luauSyntaxCode);
  console.log('Syntax Result:', syntaxResult);
  assert(syntaxResult.vec.x === 15 && syntaxResult.vec.y === 35, 'Luau vector addition succeeded');
  assert(syntaxResult.counter === 300, 'Compound assignment (+=, *=) succeeded');
  assert(syntaxResult.oddSum === 25, 'Continue statement worked correctly');
  assert(syntaxResult.greeting === 'Result is 50', 'Luau string interpolation syntax worked');

  // 3. JS to Luau Globals Interop
  console.log('\n--- Test 3: JS to Luau Globals & Types ---');
  engine.set('jsString', 'Hello from Node.js runtime');
  engine.set('jsNumber', 42.5);
  engine.set('jsBool', true);
  engine.set('jsArray', [10, 20, 30, 40]);
  engine.set('jsObject', { app: 'LuauWASM', status: 'optimal', code: 200 });

  const globalsCheck = engine.doString(`
    return {
      str = jsString,
      num = jsNumber,
      bool = jsBool,
      arrFirst = jsArray[1],
      arrLen = #jsArray,
      objApp = jsObject.app,
      objCode = jsObject.code
    }
  `);
  assert(globalsCheck.str === 'Hello from Node.js runtime', 'String global passed');
  assert(globalsCheck.num === 42.5, 'Number global passed');
  assert(globalsCheck.bool === true, 'Boolean global passed');
  assert(globalsCheck.arrFirst === 10 && globalsCheck.arrLen === 4, 'Array global converted to 1-indexed Lua table');
  assert(globalsCheck.objApp === 'LuauWASM' && globalsCheck.objCode === 200, 'Object global converted to Lua table');

  // 4. JS Callbacks (Trampoline) from Luau
  console.log('\n--- Test 4: JS Functions Called from Luau ---');
  let jsCalls = [];
  engine.register('jsMultiplier', (a, b) => {
    jsCalls.push({ a, b });
    return a * b;
  });

  engine.register('jsConcat', (s1, s2, s3) => {
    return `${s1}-${s2}-${s3}`;
  });

  const callbackRes = engine.doString(`
    local m = jsMultiplier(6, 7)
    local c = jsConcat("Alpha", "Beta", "Gamma")
    return { product = m, concat = c }
  `);
  assert(callbackRes.product === 42, 'JS multiplier callback returned correct value');
  assert(callbackRes.concat === 'Alpha-Beta-Gamma', 'JS string concatenation callback returned correct value');
  assert(jsCalls.length === 1 && jsCalls[0].a === 6 && jsCalls[0].b === 7, 'JS callback recorded correct arguments');

  // 5. WASI Stdout / Stderr / Prints
  console.log('\n--- Test 5: WASI I/O & Print Handling ---');
  stdoutLogs = [];
  engine.doString(`
    print("Luau WASI print test line 1")
    print("Luau WASI print test line 2", 123, true)
  `);
  const out = engine.getStdout();
  assert(out.includes('Luau WASI print test line 1'), 'Stdout captured line 1');
  assert(out.includes('Luau WASI print test line 2') && out.includes('123') && out.includes('true'), 'Stdout captured multi-arg print line 2');

  // 6. Luau Standard Libraries (bit32, table, string, math, utf8, os)
  console.log('\n--- Test 6: Luau Standard Libraries ---');
  const stdlibRes = engine.doString(`
    local bitRes = bit32.bxor(0xFF00, 0x0FF0)
    local t = { "cherry", "apple", "banana" }
    table.sort(t)
    local upper = string.upper("luau 0.739")
    local sqrtVal = math.sqrt(144)
    local utf8Len = utf8.len("Luau 🚀")
    
    return {
      bit = bitRes,
      sorted = t,
      upper = upper,
      sqrt = sqrtVal,
      utf8Len = utf8Len
    }
  `);
  assert(stdlibRes.bit === 0xF0F0, 'bit32 library works');
  assert(stdlibRes.sorted[0] === 'apple' && stdlibRes.sorted[2] === 'cherry', 'table.sort works');
  assert(stdlibRes.upper === 'LUAU 0.739', 'string.upper works');
  assert(stdlibRes.sqrt === 12, 'math.sqrt works');
  assert(stdlibRes.utf8Len === 6, 'utf8 library works');

  // 7. Error Handling
  console.log('\n--- Test 7: Luau Error Handling ---');
  try {
    engine.doString(`
      local x = nil
      x:nonExistentMethod()
    `);
    assert(false, 'Should have thrown runtime error');
  } catch (err) {
    assert(err.message.length > 0, `Caught expected runtime error: ${err.message}`);
  }

  try {
    engine.doString(`
      function ( broken syntax ===
    `);
    assert(false, 'Should have thrown syntax error');
  } catch (err) {
    assert(err.message.length > 0, `Caught expected syntax error: ${err.message}`);
  }

  // 8. Execution with Metrics
  console.log('\n--- Test 8: runWithMetrics API ---');
  const metricRes = engine.runWithMetrics(`
    local sum = 0
    for i = 1, 100000 do
      sum += i
    end
    print("Finished loop: " .. sum)
    return sum
  `);
  assert(metricRes.value === 5000050000, 'Metrics execution returned correct result');
  assert(metricRes.executionTimeMs >= 0, `Execution time measured: ${metricRes.executionTimeMs.toFixed(2)}ms`);
  assert(metricRes.stdout.includes('Finished loop: 5000050000'), 'Metrics execution captured stdout');

  engine.close();

  // 9. Cross-Version Consistency: Test all 6 versions together!
  console.log('\n--- Test 9: Cross-Version Compatibility (5.1.5, 5.2.4, 5.3.6, 5.4.7, 5.5.1, 0.739) ---');
  const allVersions = ['5.1.5', '5.2.4', '5.3.6', '5.4.7', '5.5.1', '0.739'];
  for (const v of allVersions) {
    const eng = await LuaEngine.create({ version: v });
    const res = eng.doString(`
      local a = 10
      local b = 25
      return a + b
    `);
    assert(res === 35, `Version ${v} executed simple arithmetic and returned 35`);
    eng.close();
  }

  console.log('\n====================================================');
  console.log(`🎉 ALL TESTS PASSED! (${passed} passed, ${failed} failed)`);
  console.log('====================================================\n');
}

runTests().catch((err) => {
  console.error('Fatal test error:', err);
  process.exit(1);
});
