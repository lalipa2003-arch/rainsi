# rainsi-lua

A multi-version Lua/Luau virtual machine for WebAssembly/WASI. Rainsi runs actual Lua 5.1.5, 5.2.4, 5.3.6, 5.4.7, 5.5.1, and Luau 0.739 WebAssembly runtimes behind a common TypeScript API.

## Features

- **Lua versions:** 5.1.5, 5.2.4, 5.3.6, 5.4.7, 5.5.1
- **Luau:** 0.739
- **WebAssembly/WASI:** browser-side WASI compatibility layer and in-memory runtime support
- **Bidirectional value marshalling:** JavaScript primitives, arrays, objects, Lua tables, and functions
- **JavaScript callbacks:** register synchronous JavaScript functions callable from Lua/Luau
- **Lua function calls:** retrieve/call Lua functions from JavaScript
- **Output capture:** stdout/stderr capture through the WASI layer
- **Common API:** the same `LuaEngine` interface is used across the supported runtimes

## Installation

```bash
npm install rainsi-lua
```

## Quick Start

```javascript
import { LuaEngine } from 'rainsi-lua';

const lua = await LuaEngine.create({ version: '5.4.7' });

lua.register('log', (msg) => console.log('[lua]', msg));

const result = lua.run(`
  log("running on " .. _VERSION)
  local t = {1, 2, 3}
  return t, 42
`);

console.log(result);
lua.close();
```

Luau can be selected with:

```javascript
const luau = await LuaEngine.create({ version: '0.739' });

const result = luau.doString(`
  local x: number = 20
  x += 22
  return x
`);

console.log(result); // 42
luau.close();
```

## JavaScript callbacks

```javascript
const luau = await LuaEngine.create({ version: '0.739' });

luau.register('jsadd', (a, b) => a + b);

console.log(luau.doString(`return jsadd(2, 3)`)); // 5

luau.close();
```

## API

### `LuaEngine.create(options)`

Creates a WebAssembly-backed Lua/Luau state.

```typescript
const engine = await LuaEngine.create({
  version: '5.4.7',
  wasmBase: 'https://example.com/wasm',
  wasmSource: wasmBytes,
  args: ['script_name'],
  onStdout: (text) => {},
  onStderr: (text) => {},
});
```

Supported versions:

```text
5.1.5
5.2.4
5.3.6
5.4.7
5.5.1
0.739 (Luau)
```

### `engine.run(code)`

Executes source and returns a success/error result.

### `engine.doString(code)`

Executes source and directly returns its Lua/Luau result, throwing on errors.

### `engine.runWithMetrics(code)`

Executes source and returns the result, captured output, errors, and execution time.

### `engine.call(name, ...args)`

Calls a global Lua/Luau function from JavaScript.

### `engine.set(name, value)` / `engine.get(name)`

Set or retrieve global values.

### `engine.register(name, fn)`

Registers a synchronous JavaScript function that Lua/Luau can call.

### `engine.close()`

Closes the Lua/Luau state and releases runtime resources.

## Testing

The repository includes Luau-specific and extended runtime tests:

```bash
npm install
npm run build
npm test
```

The Luau test suite covers syntax, type annotations, compound assignment, `continue`, string interpolation, JavaScript globals, JavaScript callbacks, WASI output, standard libraries, error handling, metrics, and cross-version initialization.

The extended suite covers coroutines, the Luau buffer library, Lua-function-to-JavaScript callables, the WASI virtual filesystem, and intensive allocation/garbage-collection workloads.

## License

MIT License.
